# YABBAI v14.0.0 — Production Evidence-First Revenue OS

YABBAI is now an evidence-first operating system for legitimate revenue discovery, opportunity ranking, agent/task orchestration, revenue verification, accounting and authorization-gated treasury operations.

## Important operating model

- No guaranteed profit or fabricated P&L.
- `$0` mode can research and queue legitimate service/research/analytics opportunities; it cannot invent customers or payments.
- Verified revenue is the only revenue that enters realized accounting.
- Capital requiring blockchain execution requires explicit user or multisig authorization.
- YABBAI does **not** store treasury private keys and never signs treasury transfers server-side.
- Unknown blockchain transaction states become reconciliation-required; they are never blindly retried.
- The 20-agent fleet evaluates independently. Signals may be shared, but execution is never synchronized or coordinated for artificial activity.
- No wash trading, artificial volume/holders, ranking manipulation, coordinated pumping or market manipulation.

## Pipeline

DISCOVER → VALIDATE → RANK → EARN → VERIFY → ACCOUNT → RESERVE → ALLOCATE → SCALE → DISCOVER AGAIN

## Opportunity score

Expected gross value minus network fees, trading fees, slippage, risk cost and capital cost. Scores are estimates until supported by authoritative evidence.

## 20-agent fleet

Twenty persistent agent slots are created automatically. Each has independent permissions, budget, risk profile, supported networks, loss/exposure limits, heartbeat and decision ID. Wallet addresses are externally supplied; private keys are never generated or stored by this service.

## Treasury lifecycle

REQUEST → VALIDATE → FETCH STATE → BUILD/PREVIEW → SIMULATE → RISK → POLICY → USER/MULTISIG AUTHORIZATION → SIGN → SUBMIT → CONFIRM → VERIFY → RECONCILE → AUDIT

The server stops at authorization. A Squads/multisig or user wallet must perform signing and execution.

Squads v4 is supported as the intended external treasury governance layer; configure its multisig/vault addresses without putting signer keys in YABBAI. The official TypeScript SDK is `@sqds/multisig`.

## RPC failover

Helius → Alchemy → QuickNode → Solana Public RPC. Credentials are server-side environment variables only and are never returned by the API.

## Persistence

Local JSON is the development fallback. Production can enable Supabase/Postgres by setting `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`, then applying `supabase/migrations/001_yabbai.sql`. RLS is enabled on the normalized tables.

## Setup

```bash
npm install
npm run setup:live
npm run lint
npm test
npm run dev
```

Do not commit `.env`. Rotate any RPC credentials that have previously been exposed outside your secret manager.

### Opportunity feeds

The registry does not fabricate earning opportunities. Set `OPPORTUNITY_FEED_URL` to an HTTPS JSON feed owned/controlled by you or a trusted provider. Each item must include a known `strategyId`; economic values remain estimates until independently verified. With no feed configured, YABBAI reports the strategy catalog and waits for real opportunities.

## Phantom wallet integration

v14.1 adds a browser-side Phantom integration without importing or storing Phantom private keys.

### Receive/fund flow

1. Connect Phantom.
2. Enter a SOL amount.
3. YABBAI builds the transfer from Phantom to the configured treasury.
4. YABBAI calculates the network fee and simulates before Phantom is prompted.
5. If preflight fails, Phantom is not prompted.
6. If preflight passes, Phantom signs and sends the real transaction.

### Initial 30% withdrawal flow

The initial withdrawal is fixed at **30% of the currently observed treasury SOL balance** for preflight. The connected Phantom address is required to be both recipient and fee payer.

YABBAI refuses to prompt Phantom when:

- the treasury has no SOL;
- the connected Phantom wallet cannot cover the fee;
- the recipient is invalid or equals the treasury;
- the transaction simulation fails.

A critical custody constraint remains: Phantom cannot authorize a transfer out of a different treasury wallet merely by paying its network fee. If the source is a Squads vault, the vault transaction must be authorized through the configured Squads governance path. Phantom can then act as fee payer/recipient for a properly constructed authorized transaction. YABBAI must never treat a successful simulation of a plain SystemProgram transfer as proof that a vault can execute it.

A processed transaction can still incur a small network fee even when an on-chain instruction later fails; dropped/expired transactions do not incur a fee. Therefore the UI uses **preflight / simulation passed** rather than promising zero-cost failure under all network races.

No Phantom seed phrase, private key, or secret is requested by YABBAI.


## v14.1.2 runtime fix
The development CSP permits the Vite React Fast Refresh preamble and HMR WebSocket during local development. Production keeps the stricter CSP. This prevents `@vitejs/plugin-react can't detect preamble` when running `npm run dev`.


## v15 Real Revenue/Tier Engine
- Zero-capital service products are first-class revenue sources.
- Verified SOL customer payments can be attached to orders and become PAID only after on-chain verification.
- Capability tiers: $0, $20, $50, $100, $250, $500, $1K, $2.5K, $5K, $10K, $25K+.
- Observed capital comes from live RPC when WATCH_WALLET is configured.
- No estimated opportunity value is counted as realized revenue.
- No guaranteed-profit logic exists.
